//#include "exam.h"

/***
 * -------------------------------------------------------------------------------------------------------------------
 * 题目
 * -------------------------------------------------------------------------------------------------------------------
 *
 * 编写一个程序，从命令行读取一个软件包的名称，调用“dpkg -L”命令获得该软件包的文件列表，并检查所有文件。
 * 要求：
 * 1. 使用cmake和c++开发
 * 2. 可执行文件名称和位置是./src/pkgverify
 * 3. 检查该软件包所有文件，确认：
 *   - 路径存在
 *   - 文件存在
 *   - 如果是符号链接，链接的文件也存在
 *   - /usr路径下的文件，确认文件属主都是root
 * 4. 输出所有有问题的文件或路径名
 *
 * 示例：
 * 如果/etc/cups路径被删除了，则运行结果如下：
 * pkgverify cups
 * /etc/cups
 * /etc/cups/snmp.conf
 *
 */


#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <unistd.h>
#include <sys/stat.h>

using namespace std;
int main(int argc, char **argv)
{
    if (argc < 2)
        return 1;
    string pkgName(argv[1]);
    string cmd = "dpkg -L " + pkgName;
    const char *tempFile = "/tmp/outputs.txt";
    freopen(tempFile, "w", stdout);
    system(cmd.c_str());
    freopen("/dev/tty", "w", stdout);

    FILE *outputs = fopen(tempFile, "r");
    if (outputs != nullptr) {
        while (!feof(outputs)) {
            char line[1024];
            memset(line, 0, 1024);
            fgets(line, 1024, outputs);
            if (strlen(line) != 0) {
                line[strlen(line) - 1] = 0;
                // 判断文件是否存在
                int ret = access(line, F_OK);
                if (ret == -1) {
                    printf("%s\n", line);
                    continue;
                }

                struct stat fileStat;
                if (lstat(line, &fileStat) < 0) {
                    continue;
                }
                // 判断文件是否是符号链接，
                // 如果是，验证其链接文件是否存在,
                // 如果不存在，打印文件路径
                if (S_ISLNK(fileStat.st_mode)) {
                    char path[1024] = {0};
                    readlink(line, path, sizeof(path));
                    if (path[0] != '/') {   // 相对路径，转为绝对路径
                        char before[1024] = {0};
                        char after[1024] = {0};
                        strcpy(after, path);
                        memset(path, 0, sizeof(path));
                        strcpy(before, line);

                        // 去掉文件名
                        size_t index = strlen(before);
                        while (index > 0) {
                            --index;
                            if (before[index] != '/') {
                                before[index] = 0;
                            } else {
                                break;
                            }
                        }

                        strcat(path, before);
                        strcat(path, after);
                    }
                    ret = access(path, F_OK);
                    if (ret == -1) {
                        printf("%s\n", line);
                        continue;
                    }
                }
                // /usr路径下的文件，确认文件属主都是root
                if (line[0] == '/' && line[1] == 'u' && line[2] == 's' && line[3] == 'r' && line[4] == '/') {
                    if (fileStat.st_uid != 0) {
                        printf("%s\n", line);
                        continue;
                    }
                }
            }
        }
        fclose(outputs);
    } else {
        printf("打开文件失败！\n");
    }

    return 0;
}
