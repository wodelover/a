//#include "exam.h"

/***
 * -------------------------------------------------------------------------------------------------------------------
 * 题目
 * -------------------------------------------------------------------------------------------------------------------
 *
 * 编写一个程序，从命令行读取一个软件包的名称，调用“dpkg -L”命令获得该软件包的文件列表，并检查所有文件。
 * 要求：
 * 1. 使用cmake和c++开发
 * 2. 可执行文件名称和位置是./src/pkgverify
 * 3. 检查该软件包所有文件，确认：
 *   - 路径存在
 *   - 文件存在
 *   - 如果是符号链接，链接的文件也存在
 *   - /usr路径下的文件，确认文件属主都是root
 * 4. 输出所有有问题的文件或路径名
 * 
 * 示例：
 * 如果/etc/cups路径被删除了，则运行结果如下：
 * pkgverify cups
 * /etc/cups
 * /etc/cups/snmp.conf
 * 
 */
 
#include <QProcess>
#include <QString>
#include <QDebug>
#include <sys/stat.h>
#include <QFileInfo>

bool fileCheck(QString file) {
    if (file.isEmpty())
        return true;

    struct stat buf;
    int res = stat(file.toStdString().c_str(), &buf);
    if (res < 0) {
//        qDebug() << "file doesn't exist" << file;
        return false;
    }

    if (S_ISLNK(buf.st_mode)) { // 链接文件
        QFileInfo info(file);
        QFileInfo target(info.symLinkTarget());
        if (!target.exists()) {
//            qDebug() << "link target doesn't exist" << file;
            return false;
        }
    }

    if (file.startsWith("/usr") && (buf.st_gid != 0 || buf.st_uid != 0)) {
//        qDebug() << "group and user error" << file;
        return false;
    }

    return true;
}


int main(int argc, char **argv) {
    if (argc < 2)
        return 1;
    QString pkgName(argv[1]);
    if (pkgName.isEmpty())
        return 0;

    QProcess p;
    p.start("dpkg", QStringList() << "-L" << pkgName);
    p.waitForFinished();
    QByteArrayList outputs = p.readAllStandardOutput().split('\n');
    QStringList errorFiles;
    foreach (auto output, outputs) {
        if (!fileCheck(output))
            errorFiles << output;
    }

    foreach (auto file, errorFiles)
        qDebug() << file;
    return 0;
}
